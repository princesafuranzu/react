import React from "react";
import AllNotifComp from "./AllNotifComp";
import EmailList from "./EmailList";
import StdTxtComp from "./StdTxtComp";
import CustomTxtArea from "./CustomTxtArea";
import ConfigStore from "../stores/ConfigStore";
import AppActions from '../actions/AppActions';

class Layout extends React.Component{
    constructor(props) {

        super(props);
        
        //ADD ZE2BUEN START
        this.handlerGetNotifConfig("BPKENN");
        //ADD ZE2BUEN START

        this.state = {
            allNotifStatus: ConfigStore.getAllNotifStatus(),
            stdTxtStatus: ConfigStore.getStdTxtStatus(),
            customTxt: ConfigStore.getCustomTxt(),
            emailList: ConfigStore.getEmailList(),
            activeEmail: ConfigStore.getActiveEmail(),
            saveMessage: ConfigStore.getSaveMessage(),
            saveStatus: ConfigStore.getSaveStatus() 
        };

    }

    componentWillMount(){
        ConfigStore.addChangeListener(this._onChange.bind(this));
    }

    componentWillUnmount(){
        ConfigStore.removeChangeListener(this._onChange);
    }

    handlerAllNotifStatus(status){
        AppActions.updateAllNotifStatus(status);
    }

    handlerStdTxtStatus(status){
        AppActions.updateStdTxtStatus(status);
    }

    handlerCustomTxt(text){
        AppActions.updateCustomText(text);
    }

    handlerEmailChange(email){
        AppActions.updateActiveEmail(email);
    }

    handlerSave(){
        AppActions.updateNotifConfig();
    }

    //ADD ZE2BUEN START
    handlerGetNotifConfig(key){
        AppActions.getNotifConfig(key);
    }
    //ADD ZE2BUEN END

    _onChange(){
        this.setState({
            allNotifStatus: ConfigStore.getAllNotifStatus(),
            stdTxtStatus: ConfigStore.getStdTxtStatus(),
            customTxt: ConfigStore.getCustomTxt(),
            emailList: ConfigStore.getEmailList(),
            activeEmail: ConfigStore.getActiveEmail(),
            saveMessage: ConfigStore.getSaveMessage(),
            saveStatus: ConfigStore.getSaveStatus() 
        });
    }

    render(){
        return(
            <div className="container">
                <p>Möchten Sie die Einstellungen Ihrer Benachrichtigungen ändern ?</p>
                <div className="container">
                    <div className="row">
                        <div className="col-md-4">
                            <p>Alle Benachrichtigungen</p>
                        </div>
                        <div className="col-md-2">
                            <AllNotifComp onChange={this.handlerAllNotifStatus} allNotifStatus= {this.state.allNotifStatus} />
                        </div>
                    </div>

                    <EmailList emailListData={this.state.emailList} onChange={this.handlerEmailChange} disabled={!this.state.allNotifStatus} value={this.state.activeEmail} />

                    <div className="row">
                        <div className="col-md-6">
                            <h4>Benachrichtigungstext</h4>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-md-4">
                            <p>Standardtext</p>
                        </div>
                        <div className="col-md-2">
                            <StdTxtComp onChange={this.handlerStdTxtStatus} stdTxtStatus= {this.state.stdTxtStatus}/>
                        </div>
                    </div>

                    <CustomTxtArea onChange={this.handlerCustomTxt} disabled={this.state.stdTxtStatus} text={this.state.customTxt}/>

                    <div className="row mt-4">
                        <div className="col-md-6">
                            <div className="col-md-6">
                                <button type="button" onClick={this.handlerSave} className={"btn btn-" +(this.state.saveStatus || "primary")}>Save</button>
                            </div>
                            <div className="col-md-6">
                                <p>{this.state.saveMessage}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Layout;