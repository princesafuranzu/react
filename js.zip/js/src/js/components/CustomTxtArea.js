import React from "react";

class CustomTxtArea extends React.Component{
	constructor(props){
		super(props);
		this.handlerTextChange = this.handlerTextChange.bind(this);
	}

	handlerTextChange(){
		this.props.onChange(document.getElementById('txt_area').value);
	}

	render(){
		return (
			<div className="row">
				<div className="col-md-4">
					<textarea id="txt_area" disabled={this.props.disabled} value={this.props.text} onChange={this.handlerTextChange} />
				</div>
			</div>
        );
	}
}

export default CustomTxtArea;



