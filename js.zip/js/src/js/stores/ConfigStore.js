import AppDispatcher from "../dispatcher/AppDispatcher";
import AppConstants from "../constants/AppConstants";
import objectAssign from "object-assign";
import { EventEmitter } from "events";
//ADD ZE2BUEN START
import jquery from "jquery";
//ADD ZE2BUEN END

const CHANGE_EVENT = "change"
//ADD ZE2BUEN START
const URL = "http://localhost:8081/BNS-WEB"
const STD_TEXT = "This is the standard notification text"
const STD = "STD";
const FREE = "FREE";
//ADD ZE2BUEN END

let allNotifStatus;
let stdTxtStatus;
let customTxt;
let emailList;
let activeEmail;

//ADD ZE2MENY START
let data;
//ADD ZE2MENY END

//ADD ZE2BUEN START
let notifConfigDetails;
let informationChannelID;
let channelStatus;    
let bpkenn;
let notifConfigUID;
let emailAddressID;
let emailUID;
let emailType;
let emailAddressUID;
let emailAddress;
let eventType;
let eventID;
let text;
let notificationTextType;
let notifTextUID;

const getNotifConfigAPI = (key) => {
	
	jquery.ajax({
      url: URL + "/getCustomer/" + key,
      dataType: 'json',
	  async: false,
      success: function(data) {
		 	console.log('retrieved data succesfully');

        	notifConfigDetails = data;

			informationChannelID = notifConfigDetails.notifConfig.informationChannelID;
			channelStatus = notifConfigDetails.notifConfig.channelStatus;
			bpkenn = notifConfigDetails.notifConfig.bpkenn;
			notifConfigUID = notifConfigDetails.notifConfig.uid;
			emailAddressID = notifConfigDetails.email.emailAddressID;
			emailUID = notifConfigDetails.email.uid;
			emailType = notifConfigDetails.emailAddress.emailType;
			emailAddressUID = notifConfigDetails.emailAddress.uid;
			emailAddress = notifConfigDetails.emailAddress.emailAddress;
			eventType = notifConfigDetails.emailAddress.eventType;
			eventID = notifConfigDetails.notifText.eventID;
			text = notifConfigDetails.notifText.text;
			notificationTextType = notifConfigDetails.notifText.notificationTextType;
			notifTextUID = notifConfigDetails.notifText.uid;

			if (emailAddress != null){
				setAllNotifStatus(true);
				setActiveEmail(emailAddress);
			}

			if (notificationTextType === STD){
				setStdTxtStatus(true);
				setCustomTxt(STD_TEXT);
			} else {
				setStdTxtStatus(false);
				setCustomTxt(text);
			}

			setEmailList([
				{email: "email1@gmail.com"},
                {email: "email2@gmail.com"},
                {email: "email3@gmail.com"}
			]);

      }.bind(this),
      error: function(xhr, status, err) {
		console.error("failed to retrieve data");
        console.error(status, err.toString());
      }.bind(this)
            
    })

};
//ADD ZE2BUEN END

//ADD ZE2MENY START
const updateConfig = () => {

	data = {
		"notifConfig":{
			"uid": notifConfigUID,
			"informationChannelID": informationChannelID,
			"channelStatus": channelStatus,
			"bpkenn": bpkenn
			},
		"email":{
			"uid": emailUID,
			"bpkenn": bpkenn,
			"emailAddressUID": emailAddressUID
			},
		"emailAddress":{ 
			"uid": emailAddressUID,
			"emailAddress": activeEmail,
			"emailType": emailType,
			"bpkenn": bpkenn
			},
		"notifText":{
			"uid": notifTextUID,
			"notificationTextType": notificationTextType,
			"eventType": eventType,
			"eventID": eventID,
			"text": customTxt},
	};

	console.log(data);

	jquery.ajax({
		type: 'POST',
		url: URL + "/updateNotifConfig",
		async: false,
		data: JSON.stringify(data),
		contentType: 'application/json',
		dataType: 'json',
		success: function(result) {
			console.log('updated successfully');
		}.bind(this),
		error: function(xhr, status, err) {
			console.error("failed to update");
        	console.error(status, err.toString());
      }.bind(this)
	});
};
//ADD ZE2MENY END

const setAllNotifStatus = (status) => {
	allNotifStatus = status;
};

const setStdTxtStatus = (status) => {
	stdTxtStatus = status;
};

const setCustomTxt = (text) => {
	customTxt = text;
};

const setEmailList = (List) => {
	emailList = List;
};

const setActiveEmail = (email) => {
	activeEmail = email;
};

const configStore = objectAssign({}, EventEmitter.prototype, {
	addChangeListener(cb){
		this.on(CHANGE_EVENT, cb);
	},

	removeChangeListener(cb){
		this.removeListener(CHANGE_EVENT, cb);
	},
	
	getAllNotifStatus(){
		return allNotifStatus;
	},

	getStdTxtStatus(){
		return stdTxtStatus;
	},

	getCustomTxt(){
		return customTxt;
	},

	getEmailList(){
		return emailList;
	},

	getActiveEmail(){
		return activeEmail;
	}
});

AppDispatcher.register(function(payload){
	const action = payload.action;
	switch(action.actionType){

		case AppConstants.GET_NOTIF_CONFIG:
		 	getNotifConfigAPI(action.data);
		break;

		case AppConstants.UPDATE_ALLNOTIF_STATUS:
		 	setAllNotifStatus(action.data);
		break;

		case AppConstants.UPDATE_STDTXT_STATUS:
		 	setStdTxtStatus(action.data);
		break;

		case AppConstants.UPDATE_CUSTOM_TXT:
		 	setCustomTxt(action.data);
		break;

		case AppConstants.UPDATE_ACTIVE_EMAIL:
		 	setActiveEmail(action.data);
		break;

		case AppConstants.UPDATE_NOTIF_CONFIG:
		 	updateConfig();
		break;

		default:
			return true;
	}

	configStore.emit(CHANGE_EVENT);
});

export default configStore;