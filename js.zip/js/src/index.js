import React from "react";
import ReactDOM from "react-dom";
import Layout from "./js/components/Layout.js"
import registerServiceWorker from "./registerServiceWorker";
import "./../node_modules/bootstrap/dist/css/bootstrap.min.css"
import "./css/style.css"

ReactDOM.render(<Layout />, document.getElementById('root'));

registerServiceWorker();
